# robots.txt directives

_Generated 2026-07-17T20:57:22.028Z_

- Base: `http://localhost:4179`
- HTTP: **200** · Content-Type: `text/plain`
- Failures: **0**

✅ robots.txt served correctly with all required Sitemap and per-bot directives.